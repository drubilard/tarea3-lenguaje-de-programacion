 package tarea3_lp;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class Hebra implements Runnable{
	ArrayList<Thread> h =  new ArrayList<Thread>();
	Random r= new Random();;
	
	public void run() {
		int i=0;
			
		try{
			Thread.sleep(100);
	    }catch (InterruptedException e) { }
	    while(i<100) {
	    	double vt= r.nextDouble();
	    	if(vt<0.001) {
	    		i+=5;
	    		
	    	}
	    }
	    System.out.println("Tarea del "+Thread.currentThread().getName()+" "+i+"% terminada");  
	}
	
	
	public synchronized void go(){
		int j=1;
		
		while(true) {	
         	for(int i=0; i<5 ; i++) {
                    h.add(new Thread(this));
                }	    	
         	h.get(0).setName("analista");
          	h.get(1).setName("diseñador");
          	h.get(2).setName("programador1");
           	h.get(3).setName("programador2");
           	h.get(4).setName("tester");	    	
          	try {
                    System.out.println(j+"º iteración");
                    h.get(0).start();
                    h.get(1).start();
                    h.get(0).join();
                    h.get(1).join();
                    h.get(2).start();
                    h.get(3).start();
                    h.get(2).join();
          	    h.get(3).join();
                    h.get(4).start();
                    h.get(4).join();
           	 }catch(Exception e) {
	    		e.printStackTrace();
             	}
         	j++;
           	h.clear();
		} 	
	  }
}